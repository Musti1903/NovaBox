package top.niunaijun.blackbox.utils;

import android.os.Build;

import java.lang.reflect.Field;
import java.util.Locale;

/**
 * Makes the Java side of the sandbox (android.os.Build) report the same device
 * identity as the native property hook (cpp/Utils/VirtualSpoof.cpp), so apps
 * that read Build.MODEL / Build.BRAND see a consistent, certified-looking phone.
 *
 * Only runs inside sandboxed app processes. Xiaomi family devices are skipped
 * because other parts of the engine rely on the real Xiaomi values.
 */
public final class DeviceSpoof {
    private static final String TAG = "DeviceSpoof";
    private static volatile boolean sApplied;

    private DeviceSpoof() {
    }

    public static void apply() {
        if (sApplied) return;
        sApplied = true;
        try {
            if (isXiaomiFamily()) {
                Slog.d(TAG, "Xiaomi family device, skipping Build spoof");
                return;
            }
            set("MANUFACTURER", "Google");
            set("BRAND", "google");
            set("MODEL", "Pixel 6");
            set("PRODUCT", "oriole");
            set("DEVICE", "oriole");
            set("FINGERPRINT", "google/oriole/oriole:12/SP1A.210812.015/7679548:user/release-keys");
            set("TAGS", "release-keys");
            set("TYPE", "user");
            set("HARDWARE", "qcom");
            set("BOARD", "lahaina");
            Slog.d(TAG, "Build fields spoofed: " + Build.BRAND + " " + Build.MODEL);
        } catch (Throwable t) {
            Slog.w(TAG, "apply failed: " + t.getMessage());
        }
    }

    private static boolean isXiaomiFamily() {
        String m = String.valueOf(Build.MANUFACTURER).toLowerCase(Locale.ROOT);
        String b = String.valueOf(Build.BRAND).toLowerCase(Locale.ROOT);
        return m.contains("xiaomi") || b.contains("xiaomi")
                || b.contains("redmi") || b.contains("poco");
    }

    private static void set(String name, String value) {
        try {
            Field field = Build.class.getDeclaredField(name);
            field.setAccessible(true);
            field.set(null, value);
        } catch (Throwable t) {
            Slog.w(TAG, "could not set Build." + name + ": " + t.getMessage());
        }
    }
}
